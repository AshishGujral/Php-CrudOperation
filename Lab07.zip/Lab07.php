<?php

// Please rename me according to the naming convention

// require the config

// require all the entities

// require all the utilities: PDO and DAO(s)

//Initialize the DAO(s)

//If there was post data from an edit form then process it
if (!empty($_POST)) {
    // if it is an edit (remember the hidden input)
    
        //Assemble the Reservation record to update        
        
        //Send the Reservation record to the DAO to be updated
        

    // it is not an edit... it means create a new record
        
        //Assemble the Reservation record to Insert/Create
        
        //Send the Reservation record to the DAO for creation
}

//If there was a delete that came in via GET
if (isset($_GET["action"]) && $_GET["action"] == "delete")  {
    //Use the DAO to delete the corresponding Reservation record
}

// Display the header (remember to set the title/heading)
// Call the HTML header

// List all Reservation.
// Note: You need to use the results from the corresponding DAO that gives you 
// the Reservation record list

//If there was a edit that came in via GET (URL query string)
if (isset($_GET["action"]) && $_GET["action"] == "edit")  {
    // Use the DAO to pull that specific Reservation record
    // Hint: notice the url link for delete.... you should have something similar with edit
    // And you can access it through $_GET
    
    // Render the  Edit Section form with the Reservation record to edit. 
    // Remember to use the correct DAO to get the facility list
} else {
    // Otherwise, it is an add new Reservation record form
}

// Finally, call the footer function
