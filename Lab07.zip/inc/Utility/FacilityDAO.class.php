<?php
/*
+-------------+------------+------+-----+---------+----------------+
| Field       | Type       | Null | Key | Default | Extra          |
+-------------+------------+------+-----+---------+----------------+
| facility_id | tinyint(3) | NO   | PRI | NULL    | auto_increment |
| short_name  | char(5)    | YES  |     | NULL    |                |
| long_name   | tinytext   | YES  |     | NULL    |                |
+-------------+------------+------+-----+---------+----------------+
*/
class FacilityDAO  {

    //Static DB member to store the database

    //Initialize the FacilityDAO
    static function initialize()    {
        //Remember to send in the class name for this DAO
    }

    //Get all the Facility
    static function getFacility() {
        // SELECT        

        //Prepare the Query
        
        //Return the resultSet
    }
}


?>