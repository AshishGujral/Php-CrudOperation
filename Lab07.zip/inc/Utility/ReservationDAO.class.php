<?php

/*
+----------------+-------------+------+-----+---------+-------+
| Field          | Type        | Null | Key | Default | Extra |
+----------------+-------------+------+-----+---------+-------+
| reservation_id | varchar(50) | YES  |     | NULL    |       |
| full_name      | varchar(50) | YES  |     | NULL    |       |
| email          | varchar(50) | YES  |     | NULL    |       |
| facility_id    | int(11)     | YES  |     | NULL    |       |
| date           | date        | YES  |     | NULL    |       |
| length         | int(11)     | YES  |     | NULL    |       |
+----------------+-------------+------+-----+---------+-------+
*/
class ReservationDAO  {

    //Static DB member to store the database    

    //Initialize the ReservationDAO
    static function initialize()    {
        //Remember to send in the class name for this DAO
    }

    // One of the functionality for the class abstracted by this DAO: CREATE
    // Remember that Create means INSERT
    static function createReservation(Reservation $newReservation) {

        // QUERY BIND EXECUTE 
        // You may want to return the last inserted id

    }
    
    // GET = READ = SELECT
    // This is for a single result.... when do I need it huh?
    static function getReservation(string $ReservationId)  {
        
        //QUERY, BIND, EXECUTE, RETURN (the single result)

    }

    // GET = READ = SELECT ALLL
    // This is to get all students, do I even need this function?
    static function getReservations() {

        // I don't need any parameter here, do I need to bind?

        
        //Prepare the Query
        //execute the query
        //Return results
    }
    
    // UPDATE means update
    static function updateReservation (Reservation $ReservationToUpdate) {

        // QUERY, BIND, EXECUTE
        // You may want to return the rowCount

    }
    
    // Sorry, I need to DELETE your record
    static function deleteReservation(string $ReservationId) {

        // Yea...yea... it is a drill like the one before  

    }

    // WE NEED TO USE JOIN HERE
    // Make sure to select from both tables joined at the correct column
    static function getReservationList() {
        //Prepare the Query
        //execute the query
        //Return row results
    }

}


?>