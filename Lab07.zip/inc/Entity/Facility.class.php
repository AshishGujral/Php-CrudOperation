<?php

Class Facility    {
    
    // Make sure to have attributes and get only the fields we need here
    // Save your time :)

    //Attributes


    //Getters
}

?>