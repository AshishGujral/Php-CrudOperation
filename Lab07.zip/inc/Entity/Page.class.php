<?php

# Make sure to complete the listReservations, addReservationForm and editReservationForm functions

class Page  {

    public static $studentName = "My Name!";
    public static $studentID = "My ID!";

    static function header()   { ?>
        <!-- Start the page 'header' -->
        <!DOCTYPE html>
        <html>
            <head>
                <title></title>
                <meta charset="utf-8">
                <meta name="author" content="Bambang">
                <title>Lab 07 <?php echo self::$studentName; ?></title>   
                <link href="css/styles.css" rel="stylesheet">     
            </head>
            <body>
                <header>
                    <h1>Lab 07: PDO CRUD with DAO -- <?php echo self::$studentName ?> (<?php echo self::$studentID ?>)</h1>
                </header>
                <article>
    <?php }

    static function footer()   { ?>
        <!-- Start the page's footer -->            
                </article>
            </body>

        </html>

    <?php }

    // This function lists all reservation records
    static function listReservations(Array $reservations)    {
    ?>
        <!-- Start the page's show data form -->
        <section class="main">
        <h2>Current Data</h2>
        <table>
            <thead>
                <tr>
                    <th>Reservation ID</th>
                    <!-- Complete the remaining header -->
                    <th>Edit</th>
                    <th>Delete</th>
            </thead>
            <?php

                //List all the sections
                $i=0;
                foreach($reservations as $reservation)  {
                    // make sure to use the correct tr class
                    // echo "<tr class=
                    
                    // ... Write your code ...
                    echo '<td><a href="?action=delete&id='.$reservation->getReservationID().'">Delete</td>';
                    echo "</tr>";
                    $i++;
                } 
        
        echo '</table>
            </section>';
  
    }

    // this function displays the add new reservation record
    static function createReservationForm(Array $facilities)   { ?>        
        <!-- Start the page's add entry form -->
        <section class="form1">
                <h3>Add Reservation</h3>
                <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
                    <table>
                        <tr>
                            <td>Reservation ID</td>
                            <td><input type="text" name="id" placeholder="132AXXAXXA"></td>
                        </tr>
                        <tr>
                            <td>Full Name</td>
                            <td><input type="text" name="fullName"></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><input type="email" name="email"></td>
                        </tr>                        
                        <tr>
                            <td>Date</td>
                            <td><input type="date" name="date"></td>
                        </tr>
                        <tr>
                            <td>Length</td>
                            <td><input type="number" min="1" max="8" step="1" name="length"></td>
                        </tr>
                        <tr>
                            <td>Facility</td>
                            <td>
                            <select name="facID">
                            <?php
                                // use loop to list all facility long names 
                                // from the database as html's option element
                            ?>
                            </select>
                            </td>
                        </tr>
                    </table>
                    <!-- Use input type hidden to let us know that this action is to create -->
                    <input type="hidden" name="action" value="create">
                    <input type="submit" value="Add Reservation">
                </form>
            </section>

    <?php }

    // This function is to show the edit reservation record form
    // The edit form should be displayed only when the edit link is clicked
    // It should be controlled in the main file.
    static function editReservationForm(Reservation $reservationToEdit, Array $facilities)   {  
        // Make sure the form's method is pointing to $_SERVER["PHP_SELF"]
        // and it is using post method
        ?>        
        <!-- Start the page's edit entry form -->
        <section class="form1">
            <h3>Edit Reservation - <?php // I should echo something here ?></h3>
            <form action="<?php // which server should I send the post? ?>" method="post">
                <table>
                    <tr>
                        <td>Reservation ID</td>
                        <td><?php // What is the reservation ID of the record? ?></td>
                    </tr>
                    <!-- 
                        You know the drill from the add new reservation form 
                        Make sure to add all input entries corresponding to the selected 
                        reservation id. Don't forget to put the values...
                    -->
                    <tr>
                        <td>Facility</td>
                        <td>
                        <select name="facID">
                        <?php
                            // use loop to list all facility long names 
                            // from the database as html's option element
                            // make sure the corresponding facility for this reservation is selected
                        ?>   
                        </select>
                        </td>
                    </tr>
                </table>
                <!-- We need another hidden input for student id here. Why? -->
                <input type="hidden" name="id" value="<?php  // what is the record's student ID again? ?>">

                <!-- Use input type hidden to let us know that this action is to edit -->
                <input type="hidden" name="action" value="edit">
                <input type="submit" value="Edit Reservation">                
            </form>
        </section>

<?php }

}